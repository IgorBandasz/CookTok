/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cookTok;

import telas.Tela_Inicio;

/**
 *
 * @author ester
 */
public class Aplicação {
    public static void main(String[] args) {
        Tela_Inicio inicio = new Tela_Inicio();
        inicio.setVisible(true);
    }
}
